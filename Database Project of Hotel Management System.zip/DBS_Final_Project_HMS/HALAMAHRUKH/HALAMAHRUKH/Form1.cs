﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace HALAMAHRUKH
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            customerBindingSource.AddNew();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'mahrukhHalaDataSet.Customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.mahrukhHalaDataSet.Customer);

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            customerBindingSource.RemoveCurrent();
                
        }

        private void button2_Click(object sender, EventArgs e)
        {
            customerBindingSource.EndEdit();
            customerTableAdapter.Update(mahrukhHalaDataSet.Customer);
            
        
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
